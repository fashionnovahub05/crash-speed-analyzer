---
name: Crash analysis product boundary
description: Product safety and scope boundary for the Crash Speed Analyzer.
---

The app is a statistical notebook for recording and reviewing historical multiplier observations only. It must not become a gambling, betting, payment, or prediction product.

**Why:** The user explicitly wants analysis and visualization without deposits, bets, casino links, automated wagering, or claims that future multipliers can be known.

**How to apply:** Keep copy focused on observed data, distributions, and historical context. Any future feature should be checked against this boundary before implementation.