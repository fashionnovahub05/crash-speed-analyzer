# Crash Speed Analyzer

A mobile-first statistical analysis tool for recording Crash-game multiplier results and reviewing historical patterns without wagering or prediction claims.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/crash-speed-analyzer/src/App.tsx` — route shell and navigation
- `artifacts/crash-speed-analyzer/src/pages/crash-pages.tsx` — dashboard, analysis, history, statistics, and settings
- `artifacts/crash-speed-analyzer/src/hooks/use-crash-data.ts` — local persistence and derived statistics
- `artifacts/crash-speed-analyzer/src/index.css` — shared visual tokens and responsive styling

## Architecture decisions

- The MVP uses browser localStorage so logging works offline and requires no external service.
- Demo history is seeded locally so analysis screens are useful on first open; Settings can reset it.
- Analysis language is descriptive and historical, never predictive or tied to wagering.

## Product

Users can record multiplier observations, review recent rounds, see distribution statistics, inspect historical trend summaries, filter/delete history, and tune display preferences on mobile or desktop.

## User preferences

- Keep the product strictly non-gambling: no bets, deposits, withdrawals, auto-bet, auto-cashout, casino links, payment features, or guaranteed prediction language.

## Gotchas

- The app is intentionally client-side for the MVP; clearing browser storage removes locally recorded history.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
