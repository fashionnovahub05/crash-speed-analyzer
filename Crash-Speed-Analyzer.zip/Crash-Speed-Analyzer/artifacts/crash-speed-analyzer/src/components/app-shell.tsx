import { type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import {
  BarChart3,
  BookOpen,
  Compass,
  Gauge,
  Home,
  Settings,
  SlidersHorizontal,
  Sparkles,
  Upload,
} from "lucide-react";
import { classifyMultiplier, formatMultiplier, type CrashRound } from "@/hooks/use-crash-data";

const navigation = [
  { href: "/", label: "Overview", icon: Home },
  { href: "/live-analysis", label: "Analysis", icon: Gauge },
  { href: "/history", label: "History", icon: BookOpen },
  { href: "/statistics", label: "Statistics", icon: BarChart3 },
  { href: "/settings", label: "Settings", icon: Settings },
];

export function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return (
    <div className="min-h-[100dvh] md:flex">
      <aside className="hidden w-[248px] shrink-0 flex-col bg-[hsl(var(--sidebar))] px-5 py-6 text-[hsl(var(--sidebar-foreground))] md:flex">
        <Link href="/" className="mb-10 flex items-center gap-3" data-testid="link-brand">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[hsl(var(--sidebar-primary))] text-[hsl(var(--sidebar-primary-foreground))]">
            <Gauge size={21} strokeWidth={2.4} />
          </div>
          <div>
            <div className="font-display text-[17px] font-semibold tracking-[-0.02em]">Crash Speed</div>
            <div className="font-data text-[9px] uppercase tracking-[0.18em] text-[hsl(var(--sidebar-foreground)/.56)]">Analyzer / 01</div>
          </div>
        </Link>
        <div className="mb-3 px-3 font-data text-[9px] uppercase tracking-[0.2em] text-[hsl(var(--sidebar-foreground)/.42)]">Workspace</div>
        <nav className="space-y-1" aria-label="Primary navigation">
          {navigation.map(({ href, label, icon: Icon }) => {
            const active = href === "/" ? location === "/" : location.startsWith(href);
            return (
              <Link
                href={href}
                key={href}
                data-testid={`link-nav-${label.toLowerCase()}`}
                className={`group flex items-center gap-3 rounded-xl px-3 py-3 text-[13px] font-medium transition-colors ${
                  active
                    ? "bg-[hsl(var(--sidebar-accent))] text-[hsl(var(--sidebar-foreground))]"
                    : "text-[hsl(var(--sidebar-foreground)/.62)] hover:bg-[hsl(var(--sidebar-accent)/.7)] hover:text-[hsl(var(--sidebar-foreground))]"
                }`}
              >
                <Icon size={17} className={active ? "text-[hsl(var(--sidebar-primary))]" : "text-[hsl(var(--sidebar-foreground)/.48)]"} />
                {label}
                {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[hsl(var(--sidebar-primary))]" />}
              </Link>
            );
          })}
        </nav>
        <div className="mt-auto rounded-2xl border border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar-accent)/.55)] p-4">
          <div className="mb-3 flex items-center gap-2">
            <span className="pulse-dot h-2 w-2 rounded-full bg-[hsl(var(--sidebar-primary))]" />
            <span className="font-data text-[9px] uppercase tracking-[0.16em] text-[hsl(var(--sidebar-primary))]">Local workspace</span>
          </div>
          <p className="text-[12px] leading-relaxed text-[hsl(var(--sidebar-foreground)/.62)]">Your rounds stay in this browser. No account, no feed, no noise.</p>
        </div>
      </aside>

      <main className="min-w-0 flex-1 pb-24 md:pb-0">
        <div className="mx-auto min-h-[100dvh] max-w-[1360px] px-4 py-5 sm:px-7 sm:py-7 lg:px-10">{children}</div>
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-[hsl(var(--border)/.9)] bg-[hsl(var(--background)/.94)] px-2 py-2 backdrop-blur-lg md:hidden" aria-label="Mobile navigation">
        <div className="mx-auto grid max-w-lg grid-cols-5">
          {navigation.map(({ href, label, icon: Icon }) => {
            const active = href === "/" ? location === "/" : location.startsWith(href);
            return (
              <Link
                href={href}
                key={href}
                data-testid={`link-mobile-nav-${label.toLowerCase()}`}
                className={`flex min-h-14 flex-col items-center justify-center gap-1 rounded-xl text-[10px] font-medium ${active ? "text-[hsl(var(--primary))]" : "text-[hsl(var(--muted-foreground))]"}`}
              >
                <Icon size={19} strokeWidth={active ? 2.3 : 1.8} />
                {label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

export function PageHeading({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow: string;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <header className="mb-7 flex flex-col gap-4 sm:mb-9 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <div className="mb-2 flex items-center gap-2 font-data text-[10px] font-medium uppercase tracking-[0.2em] text-[hsl(var(--primary))]">
          <span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--accent))]" />
          {eyebrow}
        </div>
        <h1 className="font-display text-[clamp(2rem,5vw,3.35rem)] font-semibold leading-[.95] tracking-[-0.055em] text-[hsl(var(--foreground))]">{title}</h1>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-[hsl(var(--muted-foreground))]">{description}</p>
      </div>
      {action}
    </header>
  );
}

export function MetricCard({
  label,
  value,
  detail,
  tone = "plain",
  icon: Icon,
}: {
  label: string;
  value: string;
  detail?: string;
  tone?: "plain" | "mint" | "coral" | "ink";
  icon?: typeof SlidersHorizontal;
}) {
  const styles = {
    plain: "bg-[hsl(var(--card))] border-[hsl(var(--card-border))]",
    mint: "bg-[hsl(var(--secondary)/.75)] border-[hsl(166_35%_70%)]",
    coral: "bg-[hsl(var(--accent)/.12)] border-[hsl(var(--accent)/.28)]",
    ink: "bg-[hsl(var(--sidebar))] border-[hsl(var(--sidebar))] text-[hsl(var(--sidebar-foreground))]",
  };
  return (
    <div className={`soft-shadow rounded-2xl border p-4 sm:p-5 ${styles[tone]}`} data-testid={`metric-${label.toLowerCase().replaceAll(" ", "-")}`}>
      <div className="flex items-start justify-between gap-3">
        <span className={`font-data text-[10px] uppercase tracking-[0.16em] ${tone === "ink" ? "text-[hsl(var(--sidebar-foreground)/.6)]" : "text-[hsl(var(--muted-foreground))]"}`}>{label}</span>
        {Icon && <Icon size={16} className={tone === "ink" ? "text-[hsl(var(--sidebar-primary))]" : "text-[hsl(var(--primary))]"} />}
      </div>
      <div className={`mt-3 font-data text-[clamp(1.5rem,3vw,2.25rem)] font-medium tracking-[-0.06em] ${tone === "ink" ? "text-[hsl(var(--sidebar-foreground))]" : "text-[hsl(var(--foreground))]"}`} data-testid={`value-${label.toLowerCase().replaceAll(" ", "-")}`}>{value}</div>
      {detail && <div className={`mt-1 text-[11px] ${tone === "ink" ? "text-[hsl(var(--sidebar-foreground)/.56)]" : "text-[hsl(var(--muted-foreground))]"}`}>{detail}</div>}
    </div>
  );
}

export function RoundPill({ round, index }: { round: CrashRound; index: number }) {
  const tone = classifyMultiplier(round.multiplier).toLowerCase();
  const toneClass = tone === "high" ? "bg-[hsl(var(--accent)/.14)] text-[hsl(14_68%_47%)] border-[hsl(var(--accent)/.25)]" : tone === "medium" ? "bg-[hsl(43_82%_57%/.18)] text-[hsl(31_67%_34%)] border-[hsl(43_65%_56%/.34)]" : "bg-[hsl(var(--secondary)/.7)] text-[hsl(175_35%_28%)] border-[hsl(166_30%_69%)]";
  return (
    <div className={`flex items-center justify-between rounded-xl border px-3 py-3 ${toneClass}`} data-testid={`round-pill-${round.id}`}>
      <div className="flex items-center gap-3">
        <span className="font-data text-[10px] opacity-60">{String(index + 1).padStart(2, "0")}</span>
        <span className="font-data text-sm font-medium">{formatMultiplier(round.multiplier)}</span>
      </div>
      <span className="font-data text-[9px] uppercase tracking-[0.12em] opacity-70">{tone}</span>
    </div>
  );
}

export function NonPredictiveNotice() {
  return (
    <div className="flex gap-3 rounded-2xl border border-[hsl(232_56%_52%/.2)] bg-[hsl(232_56%_52%/.07)] p-4 text-[hsl(232_48%_35%)]" data-testid="notice-non-predictive">
      <Compass size={18} className="mt-0.5 shrink-0" />
      <div>
        <p className="text-xs font-semibold">Historical lens, not a forecast</p>
        <p className="mt-1 text-[11px] leading-relaxed opacity-75">Statistical analysis only. Results are not guaranteed. These estimates describe your logged history and cannot forecast a future round.</p>
      </div>
    </div>
  );
}

export function EmptyState({ onAction }: { onAction?: () => void }) {
  return (
    <div className="instrument-grid rounded-2xl border border-dashed border-[hsl(var(--border))] px-6 py-12 text-center">
      <div className="mx-auto mb-4 flex h-11 w-11 items-center justify-center rounded-full bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]"><Upload size={19} /></div>
      <h3 className="font-display text-xl font-semibold">Your notebook is quiet</h3>
      <p className="mx-auto mt-2 max-w-xs text-sm leading-relaxed text-[hsl(var(--muted-foreground))]">Record a few multiplier rounds to make the first useful shape appear.</p>
      {onAction && <button onClick={onAction} className="mt-5 rounded-xl bg-[hsl(var(--primary))] px-4 py-2.5 text-xs font-semibold text-[hsl(var(--primary-foreground))] transition-transform active:scale-[.98]" data-testid="button-empty-add">Record first round</button>}
    </div>
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return <div className="mb-3 flex items-center gap-2 font-data text-[10px] uppercase tracking-[0.18em] text-[hsl(var(--muted-foreground))]"><span className="h-px w-5 bg-[hsl(var(--accent))]" />{children}</div>;
}

export function TinyTrend({ values }: { values: number[] }) {
  const max = Math.max(...values, 1);
  return (
    <div className="flex h-20 items-end gap-1.5" data-testid="chart-tiny-trend">
      {values.map((value, index) => (
        <div key={`${value}-${index}`} className="group relative flex h-full flex-1 items-end">
          <div className={`w-full rounded-t-sm transition-all group-hover:opacity-75 ${classifyMultiplier(value) === "HIGH" ? "bg-[hsl(var(--accent))]" : classifyMultiplier(value) === "MEDIUM" ? "bg-[hsl(43_82%_57%)]" : "bg-[hsl(var(--primary)/.62)]"}`} style={{ height: `${Math.max(10, (value / max) * 100)}%` }} title={formatMultiplier(value)} />
        </div>
      ))}
    </div>
  );
}

export { Sparkles };