import { useSyncExternalStore } from "react";

export type CrashCategory = "LOW" | "MEDIUM" | "HIGH";

export type CrashRound = {
  id: string;
  roundNumber: number;
  multiplier: number;
  createdAt: string;
  sessionId?: string;
};

export type HistoryCapacity = 100 | 500 | 1000 | 5000;
export type AnalysisThresholds = {
  lowMax: number;
  mediumMax: number;
};

const STORAGE_KEY = "crash-speed-analyzer-rounds";
const CAPACITY_KEY = "crash-speed-analyzer-capacity";
const THRESHOLDS_KEY = "crash-speed-analyzer-thresholds";
const UPDATE_EVENT = "crash-speed-analyzer-updated";
const DEFAULT_CAPACITY: HistoryCapacity = 1000;
export const DEFAULT_THRESHOLDS: AnalysisThresholds = { lowMax: 1.99, mediumMax: 4.99 };

const demoMultipliers = [
  1.14, 2.48, 1.02, 1.76, 3.2, 1.31, 1.08, 5.84, 1.42, 2.02,
  1.19, 1.67, 8.12, 1.04, 2.71, 1.55, 1.26, 4.46, 1.11, 2.34,
  1.82, 1.07, 1.63, 3.74, 1.22, 2.18, 1.36, 6.2, 1.09, 1.91,
];

export function classifyMultiplier(value: number, thresholds: AnalysisThresholds = DEFAULT_THRESHOLDS): CrashCategory {
  if (value <= thresholds.lowMax) return "LOW";
  if (value <= thresholds.mediumMax) return "MEDIUM";
  return "HIGH";
}

function makeDemoData(): CrashRound[] {
  const now = Date.now();
  return demoMultipliers.map((multiplier, index) => ({
    id: `demo-${index + 1}`,
    roundNumber: index + 1,
    multiplier,
    createdAt: new Date(now - (demoMultipliers.length - index) * 18 * 60 * 1000).toISOString(),
  }));
}

function isValidRound(value: unknown): value is CrashRound {
  if (!value || typeof value !== "object") return false;
  const round = value as Partial<CrashRound>;
  return (
    typeof round.id === "string" &&
    typeof round.roundNumber === "number" &&
    Number.isInteger(round.roundNumber) &&
    round.roundNumber > 0 &&
    typeof round.multiplier === "number" &&
    Number.isFinite(round.multiplier) &&
    round.multiplier >= 1 &&
    round.multiplier <= 100000 &&
    typeof round.createdAt === "string" &&
    !Number.isNaN(Date.parse(round.createdAt))
  );
}

function readRounds(): CrashRound[] {
  if (typeof window === "undefined") return makeDemoData();
  const stored = window.localStorage.getItem(STORAGE_KEY);
  if (!stored) {
    const demo = makeDemoData();
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(demo));
    return demo;
  }
  try {
    const parsed: unknown = JSON.parse(stored);
    if (!Array.isArray(parsed)) return makeDemoData();
    const migrated = parsed
      .filter((round): round is Partial<CrashRound> => Boolean(round && typeof round === "object"))
      .filter((round) => typeof round.id === "string" && typeof round.multiplier === "number" && Number.isFinite(round.multiplier) && round.multiplier >= 1 && round.multiplier <= 100000 && typeof round.createdAt === "string" && !Number.isNaN(Date.parse(round.createdAt)))
      .map((round, index) => ({
        id: round.id as string,
        roundNumber: typeof round.roundNumber === "number" && Number.isInteger(round.roundNumber) && round.roundNumber > 0 ? round.roundNumber : index + 1,
        multiplier: Number((round.multiplier as number).toFixed(2)),
        createdAt: round.createdAt as string,
        ...(round.sessionId ? { sessionId: String(round.sessionId).slice(0, 80) } : {}),
      }));
    return migrated.length ? migrated : makeDemoData();
  } catch {
    return makeDemoData();
  }
}

function readCapacity(): HistoryCapacity {
  if (typeof window === "undefined") return DEFAULT_CAPACITY;
  const parsed = Number(window.localStorage.getItem(CAPACITY_KEY));
  return [100, 500, 1000, 5000].includes(parsed) ? (parsed as HistoryCapacity) : DEFAULT_CAPACITY;
}

function readThresholds(): AnalysisThresholds {
  if (typeof window === "undefined") return DEFAULT_THRESHOLDS;
  try {
    const parsed = JSON.parse(window.localStorage.getItem(THRESHOLDS_KEY) ?? "") as Partial<AnalysisThresholds>;
    if (typeof parsed.lowMax === "number" && typeof parsed.mediumMax === "number" && parsed.lowMax >= 1 && parsed.mediumMax > parsed.lowMax) {
      return { lowMax: parsed.lowMax, mediumMax: parsed.mediumMax };
    }
  } catch {
    // Missing or malformed settings use the documented defaults.
  }
  return DEFAULT_THRESHOLDS;
}

let snapshot: CrashRound[] = readRounds();
let capacitySnapshot: HistoryCapacity = readCapacity();
let thresholdsSnapshot: AnalysisThresholds = readThresholds();
const listeners = new Set<() => void>();

function persist() {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
  window.localStorage.setItem(CAPACITY_KEY, String(capacitySnapshot));
  window.localStorage.setItem(THRESHOLDS_KEY, JSON.stringify(thresholdsSnapshot));
  window.dispatchEvent(new Event(UPDATE_EVENT));
  listeners.forEach((listener) => listener());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  const onStorage = () => {
    snapshot = readRounds();
    capacitySnapshot = readCapacity();
    thresholdsSnapshot = readThresholds();
    listener();
  };
  window.addEventListener(UPDATE_EVENT, onStorage);
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(listener);
    window.removeEventListener(UPDATE_EVENT, onStorage);
    window.removeEventListener("storage", onStorage);
  };
}

export function useCrashRounds() {
  const rounds = useSyncExternalStore(subscribe, () => snapshot, () => []);
  const capacity = useSyncExternalStore(subscribe, () => capacitySnapshot, () => DEFAULT_CAPACITY);
  const thresholds = useSyncExternalStore(subscribe, () => thresholdsSnapshot, () => DEFAULT_THRESHOLDS);

  const addRound = (multiplier: number, sessionId?: string) => {
    if (!Number.isFinite(multiplier) || multiplier < 1 || multiplier > 100000) {
      return { ok: false, error: "Use a multiplier between 1.00x and 100,000.00x." };
    }
    const normalized = Number(multiplier.toFixed(2));
    const latest = snapshot[snapshot.length - 1];
    if (latest && latest.multiplier === normalized && Date.now() - Date.parse(latest.createdAt) < 1500) {
      return { ok: false, error: "That round was just recorded. Check the value before submitting again." };
    }
    const nextRound: CrashRound = {
      id: `round-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      roundNumber: (snapshot.reduce((max, round) => Math.max(max, round.roundNumber), 0) || 0) + 1,
      multiplier: normalized,
      createdAt: new Date().toISOString(),
      ...(sessionId?.trim() ? { sessionId: sessionId.trim().slice(0, 80) } : {}),
    };
    snapshot = [...snapshot, nextRound].slice(-capacitySnapshot);
    persist();
    return { ok: true, round: nextRound };
  };

  const deleteRound = (id: string) => {
    snapshot = snapshot.filter((round) => round.id !== id);
    persist();
  };

  const clearRounds = () => {
    snapshot = [];
    persist();
  };

  const resetRounds = () => {
    snapshot = makeDemoData();
    persist();
  };

  const setCapacity = (nextCapacity: HistoryCapacity) => {
    capacitySnapshot = nextCapacity;
    snapshot = snapshot.slice(-nextCapacity);
    persist();
  };

  const setThresholds = (nextThresholds: AnalysisThresholds) => {
    if (nextThresholds.lowMax < 1 || nextThresholds.mediumMax <= nextThresholds.lowMax) return false;
    thresholdsSnapshot = { lowMax: Number(nextThresholds.lowMax.toFixed(2)), mediumMax: Number(nextThresholds.mediumMax.toFixed(2)) };
    persist();
    return true;
  };

  return { rounds, capacity, thresholds, addRound, deleteRound, clearRounds, resetRounds, setCapacity, setThresholds };
}

export function getRoundStats(rounds: CrashRound[], thresholds: AnalysisThresholds = DEFAULT_THRESHOLDS) {
  const values = rounds.map((round) => round.multiplier).sort((a, b) => a - b);
  const total = values.length;
  const average = total ? values.reduce((sum, value) => sum + value, 0) / total : 0;
  const median = total ? (values[Math.floor((total - 1) / 2)] + values[Math.ceil((total - 1) / 2)]) / 2 : 0;
  const highCount = values.filter((value) => classifyMultiplier(value, thresholds) === "HIGH").length;
  const mediumCount = values.filter((value) => classifyMultiplier(value, thresholds) === "MEDIUM").length;
  const lowCount = values.filter((value) => classifyMultiplier(value, thresholds) === "LOW").length;
  return {
    total,
    average,
    median,
    highest: total ? values[total - 1] : 0,
    lowest: total ? values[0] : 0,
    highCount,
    mediumCount,
    lowCount,
  };
}

export type StatisticalAnalysis = {
  current: number;
  recentAverage: number;
  recentMedian: number;
  category: CrashCategory;
  frequencies: { LOW: number; MEDIUM: number; HIGH: number };
  highFrequency: number;
  streak: { category: CrashCategory; length: number };
  historicalDistribution: { LOW: number; MEDIUM: number; HIGH: number };
  volatility: number;
  similarity: number;
  historicalMatchCount: number;
  postMatchAverage: number;
  postMatchCategory: CrashCategory | null;
  confidence: "LOW" | "MEDIUM" | "HIGH";
  range: { low: number; high: number };
};

export function getStatisticalAnalysis(rounds: CrashRound[], thresholds: AnalysisThresholds = DEFAULT_THRESHOLDS): StatisticalAnalysis | null {
  if (!rounds.length) return null;
  const values = rounds.map((round) => round.multiplier);
  const recent = values.slice(-8);
  const recentStats = getRoundStats(rounds.slice(-8), thresholds);
  const categories = values.map((value) => classifyMultiplier(value, thresholds));
  const counts = { LOW: 0, MEDIUM: 0, HIGH: 0 };
  categories.forEach((category) => { counts[category] += 1; });
  const recentCategories = categories.slice(-8);
  const recentCounts = { LOW: 0, MEDIUM: 0, HIGH: 0 };
  recentCategories.forEach((category) => { recentCounts[category] += 1; });
  const mean = recent.length ? recent.reduce((sum, value) => sum + value, 0) / recent.length : 0;
  const volatility = recent.length > 1 ? Math.sqrt(recent.reduce((sum, value) => sum + (value - mean) ** 2, 0) / recent.length) : 0;
  const streakCategory = categories[categories.length - 1];
  let streakLength = 0;
  for (let i = categories.length - 1; i >= 0 && categories[i] === streakCategory; i -= 1) streakLength += 1;
  const windowSize = Math.min(4, values.length);
  const currentWindow = categories.slice(-windowSize);
  let historicalMatchCount = 0;
  const following: CrashRound[] = [];
  let bestSimilarity = 0;
  for (let i = 0; i + windowSize < categories.length - 1; i += 1) {
    const match = currentWindow.reduce((score, category, index) => score + (categories[i + index] === category ? 1 : 0), 0) / windowSize;
    if (match >= 0.75) {
      historicalMatchCount += 1;
      following.push(rounds[i + windowSize]);
      bestSimilarity = Math.max(bestSimilarity, match);
    }
  }
  const postMatchAverage = following.length ? following.reduce((sum, round) => sum + round.multiplier, 0) / following.length : 0;
  const postMatchCategory = following.length ? classifyMultiplier(postMatchAverage, thresholds) : null;
  const confidence = rounds.length >= 50 && historicalMatchCount >= 5 ? "HIGH" : rounds.length >= 20 && historicalMatchCount >= 2 ? "MEDIUM" : "LOW";
  const spread = Math.max(volatility * 0.5, 0.25);
  return {
    current: values[values.length - 1],
    recentAverage: recentStats.average,
    recentMedian: recentStats.median,
    category: classifyMultiplier(values[values.length - 1], thresholds),
    frequencies: recentCounts,
    highFrequency: recent.length ? recentCounts.HIGH / recent.length : 0,
    streak: { category: streakCategory, length: streakLength },
    historicalDistribution: { LOW: counts.LOW / values.length, MEDIUM: counts.MEDIUM / values.length, HIGH: counts.HIGH / values.length },
    volatility,
    similarity: Math.round(bestSimilarity * 100),
    historicalMatchCount,
    postMatchAverage,
    postMatchCategory,
    confidence,
    range: { low: Math.max(1, mean - spread), high: mean + spread },
  };
}

export function formatMultiplier(value: number) {
  return `${value.toFixed(2)}x`;
}