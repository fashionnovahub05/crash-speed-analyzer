import { type FormEvent, type ReactNode, useMemo, useState } from "react";
import { Link } from "wouter";
import {
  ArrowRight,
  BarChart3,
  Check,
  ChevronRight,
  CircleHelp,
  Database,
  Download,
  FileText,
  Info,
  Layers3,
  ListFilter,
  Plus,
  RotateCcw,
  Search,
  SlidersHorizontal,
  Trash2,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import { AppShell, EmptyState, MetricCard, NonPredictiveNotice, PageHeading, RoundPill, SectionLabel, TinyTrend } from "@/components/app-shell";
import { classifyMultiplier, formatMultiplier, getRoundStats, getStatisticalAnalysis, type HistoryCapacity, useCrashRounds } from "@/hooks/use-crash-data";

function formatTime(value: string) {
  return new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(new Date(value));
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric", year: "numeric" }).format(new Date(value));
}

function AppFrame({ children }: { children: ReactNode }) {
  return <AppShell>{children}</AppShell>;
}

export function HomePage() {
  const { rounds, thresholds } = useCrashRounds();
  const stats = getRoundStats(rounds, thresholds);
  const recent = [...rounds].reverse().slice(0, 8);
  const chart = [...rounds].slice(-14).map((round) => round.multiplier);
  return (
    <AppFrame>
      <PageHeading
        eyebrow="Overview / local notebook"
        title="Read the shape of your rounds."
        description="A quiet place to review volatility, range, and repetition in the multiplier history you choose to log."
        action={<Link href="/history" className="inline-flex w-fit items-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-4 py-3 text-xs font-semibold text-[hsl(var(--primary-foreground))] transition-transform hover:-translate-y-0.5 active:translate-y-0" data-testid="link-start-analysis"><Plus size={15} /> Record a round <ArrowRight size={14} /></Link>}
      />

      <div className="appear mb-5 overflow-hidden rounded-[1.35rem] border border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar))] text-[hsl(var(--sidebar-foreground))] sm:mb-7">
        <div className="instrument-grid grid gap-5 p-5 sm:p-7 lg:grid-cols-[1fr_280px] lg:items-center">
          <div>
            <div className="mb-4 flex items-center gap-2 font-data text-[10px] uppercase tracking-[.18em] text-[hsl(var(--sidebar-primary))]"><span className="pulse-dot h-2 w-2 rounded-full bg-[hsl(var(--sidebar-primary))]" /> Instrument ready</div>
            <h2 className="max-w-xl font-display text-[clamp(1.65rem,4vw,2.7rem)] font-semibold leading-[1.02] tracking-[-.045em]">Every logged round adds resolution.</h2>
            <p className="mt-3 max-w-md text-sm leading-relaxed text-[hsl(var(--sidebar-foreground)/.62)]">Start with the numbers you already have. Crash Speed Analyzer keeps the focus on observation, not outcomes.</p>
          </div>
          <div className="rounded-2xl border border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar-accent)/.6)] p-4">
            <div className="flex items-center justify-between text-[10px] uppercase tracking-[.15em] text-[hsl(var(--sidebar-foreground)/.5)]"><span>Latest entry</span><FileText size={14} /></div>
            <div className="mt-4 font-data text-4xl tracking-[-.08em] text-[hsl(var(--sidebar-primary))]" data-testid="text-latest-round">{rounds.length ? formatMultiplier(recent[0].multiplier) : "—"}</div>
            <div className="mt-1 text-xs text-[hsl(var(--sidebar-foreground)/.58)]">{rounds.length ? `Logged ${formatTime(recent[0].createdAt)}` : "Waiting for your first entry"}</div>
          </div>
        </div>
      </div>

      <div className="mb-8 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <MetricCard label="Total rounds" value={String(stats.total)} detail="All logged observations" icon={Database} />
        <MetricCard label="Average" value={stats.total ? formatMultiplier(stats.average) : "—"} detail="Arithmetic mean" tone="mint" icon={BarChart3} />
        <MetricCard label="Highest" value={stats.total ? formatMultiplier(stats.highest) : "—"} detail="Observed maximum" tone="coral" icon={TrendingUp} />
        <MetricCard label="Lowest" value={stats.total ? formatMultiplier(stats.lowest) : "—"} detail="Observed minimum" tone="ink" icon={TrendingDown} />
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.3fr_.7fr]">
        <section className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-6">
          <div className="mb-5 flex items-start justify-between gap-4">
            <div><SectionLabel>Recent sequence</SectionLabel><h2 className="font-display text-2xl font-semibold tracking-[-.035em]">Last 14 rounds</h2></div>
            <Link href="/history" className="flex items-center gap-1 text-xs font-semibold text-[hsl(var(--primary))]" data-testid="link-view-history">View history <ChevronRight size={14} /></Link>
          </div>
          {rounds.length ? <TinyTrend values={chart} /> : <EmptyState />}
          <div className="mt-4 flex justify-between font-data text-[9px] uppercase tracking-[.14em] text-[hsl(var(--muted-foreground))]"><span>Earlier</span><span>Most recent</span></div>
        </section>
        <section className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-6">
          <SectionLabel>Band count</SectionLabel>
          <h2 className="font-display text-2xl font-semibold tracking-[-.035em]">How the log clusters</h2>
          <div className="mt-6 space-y-4">
            {[
               ["Low", stats.lowCount, "1.00x — 1.99x", "bg-[hsl(var(--primary))]"],
               ["Medium", stats.mediumCount, "2.00x — 4.99x", "bg-[hsl(43_82%_57%)]"],
               ["High", stats.highCount, "5.00x and above", "bg-[hsl(var(--accent))]"],
            ].map(([label, count, hint, color]) => (
              <div key={label as string} data-testid={`band-${String(label).toLowerCase()}`}>
                <div className="mb-1.5 flex items-center justify-between text-xs"><span className="font-medium">{label}</span><span className="font-data text-[hsl(var(--muted-foreground))]">{count} / {stats.total}</span></div>
                <div className="h-2 overflow-hidden rounded-full bg-[hsl(var(--muted))]"><div className={`h-full rounded-full ${color}`} style={{ width: stats.total ? `${(Number(count) / stats.total) * 100}%` : "0%" }} /></div>
                <div className="mt-1 font-data text-[9px] uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))]">{hint}</div>
              </div>
            ))}
          </div>
        </section>
      </div>

      <section className="mt-5 rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-6">
        <div className="mb-4 flex items-center justify-between"><div><SectionLabel>Latest observations</SectionLabel><h2 className="font-display text-2xl font-semibold tracking-[-.035em]">Recent rounds</h2></div><Link href="/live-analysis" className="text-xs font-semibold text-[hsl(var(--primary))]" data-testid="link-open-analysis">Open analysis <ArrowRight size={13} className="ml-1 inline" /></Link></div>
        {recent.length ? <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">{recent.slice(0, 4).map((round, index) => <RoundPill key={round.id} round={round} index={index} />)}</div> : <EmptyState />}
      </section>
    </AppFrame>
  );
}

export function LiveAnalysisPage() {
  const { rounds, thresholds } = useCrashRounds();
  const analysis = getStatisticalAnalysis(rounds, thresholds);
  const latest = rounds[rounds.length - 1];
  const recent = rounds.slice(-8);
  const prior = rounds.slice(-16, -8);
  const recentAverage = analysis?.recentAverage ?? 0;
  const priorAverage = prior.length ? prior.reduce((sum, item) => sum + item.multiplier, 0) / prior.length : 0;
  const movement = recentAverage - priorAverage;
  return (
    <AppFrame>
      <PageHeading eyebrow="Analysis / historical estimates" title="A closer read of the log." description="Contextual signals derived from your recorded rounds, kept deliberately separate from any idea of prediction." action={<div className="flex items-center gap-2 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card)/.7)] px-3 py-2 font-data text-[10px] uppercase tracking-[.14em] text-[hsl(var(--muted-foreground))]"><span className="pulse-dot h-2 w-2 rounded-full bg-[hsl(var(--accent))]" /> Snapshot live</div>} />
      <div className="mb-5"><NonPredictiveNotice /></div>
      {!rounds.length || !analysis || !latest ? <EmptyState /> : (
        <>
          <div className="grid gap-5 lg:grid-cols-[.95fr_1.05fr]">
            <section className="instrument-grid relative overflow-hidden rounded-[1.35rem] border border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar))] p-6 text-[hsl(var(--sidebar-foreground))] sm:p-8">
              <div className="absolute -right-12 -top-12 h-36 w-36 rounded-full border border-[hsl(var(--sidebar-primary)/.16)]" />
              <div className="absolute -right-5 top-[-1.75rem] h-24 w-24 rounded-full border border-[hsl(var(--sidebar-primary)/.12)]" />
              <SectionLabel>Current</SectionLabel>
              <div className="mt-8 font-data text-[clamp(3.8rem,11vw,6.5rem)] leading-none tracking-[-.11em] text-[hsl(var(--sidebar-primary))]" data-testid="text-current-multiplier">{formatMultiplier(latest.multiplier)}</div>
              <p className="mt-4 max-w-sm text-sm leading-relaxed text-[hsl(var(--sidebar-foreground)/.62)]">Most recent recorded observation · {analysis.category} category.</p>
              <div className="mt-8 flex items-center gap-2 text-[10px] uppercase tracking-[.15em] text-[hsl(var(--sidebar-foreground)/.52)]"><span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--accent))]" /> Updated {formatTime(latest.createdAt)}</div>
            </section>
            <section className="rounded-[1.35rem] border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-6 sm:p-8">
              <SectionLabel>Statistical range</SectionLabel>
              <h2 className="font-display text-2xl font-semibold tracking-[-.035em]">{formatMultiplier(analysis.range.low)} — {formatMultiplier(analysis.range.high)}</h2>
              <div className="mt-7 grid gap-3 sm:grid-cols-3">
                {[
                   ["LOW", `${Math.round(analysis.frequencies.LOW / recent.length * 100)}%`, analysis.frequencies.LOW, "bg-[hsl(var(--primary)/.08)] text-[hsl(var(--primary))]"],
                   ["MEDIUM", `${Math.round(analysis.frequencies.MEDIUM / recent.length * 100)}%`, analysis.frequencies.MEDIUM, "bg-[hsl(43_82%_57%/.16)] text-[hsl(31_67%_34%)]"],
                   ["HIGH", `${Math.round(analysis.frequencies.HIGH / recent.length * 100)}%`, analysis.frequencies.HIGH, "bg-[hsl(var(--accent)/.12)] text-[hsl(14_68%_47%)]"],
                ].map(([label, range, count, style]) => <div key={label as string} className={`rounded-xl p-4 ${style}`} data-testid={`analysis-range-${String(label).toLowerCase()}`}><div className="font-data text-[10px] font-medium tracking-[.14em]">{label}</div><div className="mt-1 font-data text-xl">{count}</div><div className="mt-1 text-[10px] opacity-70">{range} of recent</div></div>)}
              </div>
              <div className="mt-7 border-t border-[hsl(var(--border))] pt-5"><div className="mb-2 flex justify-between text-xs"><span className="text-[hsl(var(--muted-foreground))]">Volatility</span><span className="font-data">{formatMultiplier(analysis.volatility)}</span></div><div className="text-xs text-[hsl(var(--muted-foreground))]">Recent median {formatMultiplier(analysis.recentMedian)} · high frequency {Math.round(analysis.highFrequency * 100)}%</div></div>
            </section>
          </div>
          <div className="mt-5 grid gap-5 md:grid-cols-3">
             <MetricCard label="Pattern similarity" value={`${analysis.similarity}%`} detail="Matched against earlier sequences" tone="mint" icon={Layers3} />
            <MetricCard label="Confidence" value={analysis.confidence} detail={`${rounds.length} observations · descriptive only`} icon={CircleHelp} />
            <MetricCard label="Recent trend" value={movement > .08 ? "Rising" : movement < -.08 ? "Cooling" : "Balanced"} detail={`Streak: ${analysis.streak.category} ×${analysis.streak.length}`} tone={movement > .08 ? "coral" : "plain"} icon={movement > .08 ? TrendingUp : TrendingDown} />
          </div>
          <div className="mt-5 grid gap-5 lg:grid-cols-[1.3fr_.7fr]">
            <section className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-6"><SectionLabel>Sequence context</SectionLabel><h2 className="font-display text-2xl font-semibold tracking-[-.035em]">The latest eight</h2><div className="mt-5"><TinyTrend values={recent.map((round) => round.multiplier)} /></div><div className="mt-4 grid grid-cols-4 gap-2 sm:grid-cols-8">{recent.map((round, index) => <div key={round.id} className="text-center" data-testid={`analysis-round-${round.id}`}><div className="font-data text-[11px]">{formatMultiplier(round.multiplier)}</div><div className="mt-1 font-data text-[9px] text-[hsl(var(--muted-foreground))]">{String(index + 1).padStart(2, "0")}</div></div>)}</div></section>
             <section className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-6"><SectionLabel>Historical matches</SectionLabel><div className="flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]"><Check size={19} /></div><div><h2 className="font-display text-2xl font-semibold tracking-[-.035em]">{analysis.historicalMatchCount}</h2><p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">Earlier similar windows</p></div></div><p className="mt-6 text-sm leading-relaxed text-[hsl(var(--muted-foreground))]">{analysis.postMatchAverage ? `What followed those matches averaged ${formatMultiplier(analysis.postMatchAverage)} (${analysis.postMatchCategory}).` : "More matching windows will appear as the notebook grows."}</p></section>
          </div>
        </>
      )}
    </AppFrame>
  );
}

export function HistoryPage() {
  const { rounds, thresholds, addRound, deleteRound, clearRounds } = useCrashRounds();
  const [value, setValue] = useState("");
  const [sessionId, setSessionId] = useState("");
  const [feedback, setFeedback] = useState<{ type: "error" | "success"; text: string } | null>(null);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"ALL" | "LOW" | "MEDIUM" | "HIGH">("ALL");
  const [sort, setSort] = useState<"newest" | "oldest" | "highest" | "lowest">("newest");
  const [confirmClear, setConfirmClear] = useState(false);
  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return [...rounds]
      .filter((round) => {
        const category = classifyMultiplier(round.multiplier, thresholds);
        return (filter === "ALL" || category === filter) &&
          (!normalized || String(round.roundNumber).includes(normalized) || formatMultiplier(round.multiplier).includes(normalized) || round.sessionId?.toLowerCase().includes(normalized));
      })
      .sort((a, b) => sort === "oldest" ? a.roundNumber - b.roundNumber : sort === "highest" ? b.multiplier - a.multiplier : sort === "lowest" ? a.multiplier - b.multiplier : b.roundNumber - a.roundNumber);
  }, [filter, query, rounds, sort, thresholds]);

  function submitRound(event: FormEvent) {
    event.preventDefault();
    const parsed = Number(value);
    if (!value.trim() || !Number.isFinite(parsed)) return setFeedback({ type: "error", text: "Enter a valid multiplier." });
    const result = addRound(parsed, sessionId);
    if (!result.ok) return setFeedback({ type: "error", text: result.error ?? "That value could not be recorded." });
    setValue("");
    setSessionId("");
    setFeedback({ type: "success", text: `${formatMultiplier(parsed)} added as round ${result.round?.roundNumber}.` });
  }
  function removeRound(id: string) {
    deleteRound(id);
    setFeedback({ type: "success", text: "Round removed from this notebook." });
  }
  function exportHistory() {
    const headers = ["Round", "Multiplier", "Timestamp", "Session ID", "Category"];
    const rows = rounds.map((round) => [round.roundNumber, formatMultiplier(round.multiplier), round.createdAt, round.sessionId ?? "", classifyMultiplier(round.multiplier, thresholds)]);
    const csv = [headers, ...rows].map((row) => row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "crash-speed-history.csv";
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <AppFrame>
      <PageHeading eyebrow="History / record & review" title="Your round notebook." description="Add observations one at a time, then scan them in reverse order. Data stays on this device." action={<div className="flex items-center gap-2 font-data text-[10px] uppercase tracking-[.14em] text-[hsl(var(--muted-foreground))]"><Database size={14} className="text-[hsl(var(--primary))]" /> {rounds.length} stored locally</div>} />
      <div className="grid gap-5 lg:grid-cols-[.72fr_1.28fr] lg:items-start">
        <section className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-6 lg:sticky lg:top-6">
          <SectionLabel>New observation</SectionLabel>
          <h2 className="font-display text-2xl font-semibold tracking-[-.035em]">Record a multiplier</h2>
          <p className="mt-2 text-sm leading-relaxed text-[hsl(var(--muted-foreground))]">Keep the raw number clean. We’ll sort it into a band for review.</p>
            <form onSubmit={submitRound} className="mt-7">
            <label htmlFor="multiplier" className="mb-2 block font-data text-[10px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]">Multiplier</label>
            <div className="flex items-center rounded-xl border border-[hsl(var(--input))] bg-[hsl(var(--background)/.55)] px-4 transition-colors focus-within:border-[hsl(var(--primary))] focus-within:ring-2 focus-within:ring-[hsl(var(--primary)/.12)]"><input id="multiplier" inputMode="decimal" value={value} onChange={(event) => { setValue(event.target.value); setFeedback(null); }} placeholder="1.42" className="min-w-0 flex-1 bg-transparent py-4 font-data text-2xl outline-none placeholder:text-[hsl(var(--muted-foreground)/.45)]" data-testid="input-multiplier" /><span className="font-data text-sm text-[hsl(var(--muted-foreground))]">x</span></div>
            <p className="mt-2 text-[11px] text-[hsl(var(--muted-foreground))]">Numbers only · 1.00x minimum · two decimals kept</p>
             <label htmlFor="session-id" className="mb-2 mt-5 block font-data text-[10px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]">Session ID <span className="normal-case tracking-normal">(optional)</span></label>
             <input id="session-id" value={sessionId} onChange={(event) => setSessionId(event.target.value)} maxLength={80} placeholder="e.g. morning-session" className="w-full rounded-xl border border-[hsl(var(--input))] bg-[hsl(var(--background)/.55)] px-4 py-3 text-sm outline-none focus:border-[hsl(var(--primary))]" data-testid="input-session-id" />
            <button type="submit" className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-[hsl(var(--primary))] py-3.5 text-xs font-semibold text-[hsl(var(--primary-foreground))] transition-transform hover:-translate-y-0.5 active:translate-y-0" data-testid="button-add-round"><Plus size={16} /> Add to history</button>
          </form>
          {feedback && <div className={`mt-4 flex items-start gap-2 rounded-xl p-3 text-xs ${feedback.type === "success" ? "bg-[hsl(var(--secondary))] text-[hsl(175_35%_25%)]" : "bg-[hsl(var(--destructive)/.1)] text-[hsl(var(--destructive))]"}`} data-testid={`status-history-${feedback.type}`}><span className="mt-0.5">{feedback.type === "success" ? <Check size={14} /> : <Info size={14} />}</span>{feedback.text}</div>}
          <div className="mt-8 border-t border-[hsl(var(--border))] pt-5"><div className="flex items-center gap-2 text-xs font-semibold"><Info size={14} className="text-[hsl(var(--primary))]" /> Recording principle</div><p className="mt-2 text-[11px] leading-relaxed text-[hsl(var(--muted-foreground))]">A clean history can help you understand variability. It cannot make the next round knowable.</p></div>
        </section>
        <section className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-6">
          <div className="mb-5 space-y-3"><div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div><SectionLabel>Round log</SectionLabel><h2 className="font-display text-2xl font-semibold tracking-[-.035em]">Recorded rounds</h2></div><div className="flex gap-2"><button onClick={exportHistory} disabled={!rounds.length} className="inline-flex items-center gap-2 rounded-xl border border-[hsl(var(--border))] px-3 py-2 text-xs font-semibold disabled:opacity-40" data-testid="button-export-history"><Download size={14} /> Export</button><button onClick={() => setConfirmClear(true)} disabled={!rounds.length} className="inline-flex items-center gap-2 rounded-xl border border-[hsl(var(--accent)/.3)] px-3 py-2 text-xs font-semibold text-[hsl(14_68%_47%)] disabled:opacity-40" data-testid="button-clear-history"><Trash2 size={14} /> Clear</button></div></div><div className="grid gap-2 sm:grid-cols-[1fr_auto_auto]"><label className="flex items-center gap-2 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background)/.45)] px-3"><Search size={15} className="text-[hsl(var(--muted-foreground))]" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search round, multiplier, session" className="min-w-0 flex-1 bg-transparent py-3 text-xs outline-none" aria-label="Search history" data-testid="input-search-history" /></label><select value={sort} onChange={(event) => setSort(event.target.value as typeof sort)} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background)/.45)] px-3 py-2 text-xs" aria-label="Sort history" data-testid="select-sort-history"><option value="newest">Newest</option><option value="oldest">Oldest</option><option value="highest">Highest</option><option value="lowest">Lowest</option></select><select value={filter} onChange={(event) => setFilter(event.target.value as typeof filter)} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background)/.45)] px-3 py-2 text-xs" aria-label="Filter history" data-testid="select-filter-history"><option value="ALL">All categories</option><option value="LOW">LOW</option><option value="MEDIUM">MEDIUM</option><option value="HIGH">HIGH</option></select></div></div>
           {confirmClear && <div className="mb-4 flex flex-col gap-3 rounded-xl border border-[hsl(var(--accent)/.3)] bg-[hsl(var(--accent)/.06)] p-4 text-xs sm:flex-row sm:items-center sm:justify-between"><span>Clear all {rounds.length} recorded rounds? This cannot be undone.</span><div className="flex gap-2"><button onClick={() => { clearRounds(); setConfirmClear(false); setFeedback({ type: "success", text: "History cleared." }); }} className="rounded-lg bg-[hsl(var(--accent))] px-3 py-2 font-semibold text-white" data-testid="button-confirm-clear">Clear history</button><button onClick={() => setConfirmClear(false)} className="rounded-lg border border-[hsl(var(--border))] px-3 py-2 font-semibold">Cancel</button></div></div>}
           {filtered.length ? <div className="overflow-x-auto"><div className="min-w-[560px] divide-y divide-[hsl(var(--border))]"><div className="grid grid-cols-[.55fr_1fr_1.35fr_1fr_1fr_auto] gap-3 pb-2 font-data text-[9px] uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))]"><span>Round</span><span>Multiplier</span><span>Time</span><span>Session</span><span>Category</span><span /></div>{filtered.map((round) => { const category = classifyMultiplier(round.multiplier, thresholds); return <div key={round.id} className="group grid grid-cols-[.55fr_1fr_1.35fr_1fr_1fr_auto] items-center gap-3 py-3" data-testid={`row-history-${round.id}`}><span className="font-data text-[11px] text-[hsl(var(--muted-foreground))]">#{round.roundNumber}</span><span className="font-data text-[15px]">{formatMultiplier(round.multiplier)}</span><span className="text-[11px] text-[hsl(var(--muted-foreground))]">{formatDate(round.createdAt)} · {formatTime(round.createdAt)}</span><span className="truncate text-[11px] text-[hsl(var(--muted-foreground))]">{round.sessionId || "—"}</span><span className={`w-fit rounded-full px-2 py-1 font-data text-[9px] uppercase tracking-[.12em] ${category === "HIGH" ? "bg-[hsl(var(--accent)/.12)] text-[hsl(14_68%_47%)]" : category === "MEDIUM" ? "bg-[hsl(43_82%_57%/.16)] text-[hsl(31_67%_34%)]" : "bg-[hsl(var(--secondary))] text-[hsl(175_35%_25%)]"}`}>{category}</span><button onClick={() => removeRound(round.id)} className="rounded-lg p-2 text-[hsl(var(--muted-foreground))] opacity-70 transition-colors hover:bg-[hsl(var(--destructive)/.1)] hover:text-[hsl(var(--destructive))] sm:opacity-0 sm:group-hover:opacity-100" aria-label={`Delete round ${round.roundNumber}`} data-testid={`button-delete-round-${round.id}`}><Trash2 size={15} /></button></div>; })}</div></div> : <EmptyState onAction={() => document.getElementById("multiplier")?.focus()} />}
        </section>
      </div>
    </AppFrame>
  );
}

export function StatisticsPage() {
  const { rounds, thresholds } = useCrashRounds();
  const stats = getRoundStats(rounds, thresholds);
  const sorted = useMemo(() => [...rounds].sort((a, b) => b.multiplier - a.multiplier), [rounds]);
   const bins = [
     { label: "LOW · 1.00–1.99x", count: stats.lowCount, color: "bg-[hsl(var(--primary))]" },
     { label: "MEDIUM · 2.00–4.99x", count: stats.mediumCount, color: "bg-[hsl(43_82%_57%)]" },
     { label: "HIGH · 5.00x+", count: stats.highCount, color: "bg-[hsl(var(--accent))]" },
  ];
  return (
    <AppFrame>
      <PageHeading eyebrow="Statistics / historical distribution" title="The numbers, distilled." description="A compact statistical view of the values in your notebook. Descriptive only: the past does not set the next result." action={<Link href="/history" className="inline-flex items-center gap-2 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-4 py-3 text-xs font-semibold text-[hsl(var(--foreground))]" data-testid="link-statistics-history"><Plus size={15} className="text-[hsl(var(--primary))]" /> Add data</Link>} />
       {!rounds.length ? <EmptyState /> : <><div className="grid grid-cols-2 gap-3 md:grid-cols-5"><MetricCard label="Total rounds" value={String(stats.total)} detail="stored observations" icon={Database} /><MetricCard label="Average" value={formatMultiplier(stats.average)} detail="arithmetic mean" tone="mint" icon={BarChart3} /><MetricCard label="Median" value={formatMultiplier(stats.median)} detail="middle observation" icon={Layers3} /><MetricCard label="Maximum" value={formatMultiplier(stats.highest)} detail="top observation" tone="coral" icon={TrendingUp} /><MetricCard label="Minimum" value={formatMultiplier(stats.lowest)} detail="bottom observation" tone="ink" icon={TrendingDown} /></div><div className="mt-5 grid grid-cols-3 gap-3"><MetricCard label="Low count" value={String(stats.lowCount)} detail="1.00x–1.99x" /><MetricCard label="Medium count" value={String(stats.mediumCount)} detail="2.00x–4.99x" tone="mint" /><MetricCard label="High count" value={String(stats.highCount)} detail="5.00x+" tone="coral" /></div><div className="mt-5 grid gap-5 lg:grid-cols-[1.05fr_.95fr]"><section className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-6"><SectionLabel>Distribution</SectionLabel><h2 className="font-display text-2xl font-semibold tracking-[-.035em]">Where values land</h2><div className="mt-8 space-y-5">{bins.map((bin) => <div key={bin.label} data-testid={`distribution-${bin.label}`}><div className="mb-2 flex justify-between text-xs"><span className="font-medium">{bin.label}</span><span className="font-data text-[hsl(var(--muted-foreground))]">{bin.count} rounds · {Math.round((bin.count / stats.total) * 100)}%</span></div><div className="h-3 rounded-full bg-[hsl(var(--muted))]"><div className={`h-full rounded-full ${bin.color} transition-all`} style={{ width: `${(bin.count / stats.total) * 100}%` }} /></div></div>)}</div></section><section className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-6"><SectionLabel>Ranked observations</SectionLabel><h2 className="font-display text-2xl font-semibold tracking-[-.035em]">Highest logged values</h2><div className="mt-5 space-y-1">{sorted.slice(0, 6).map((round, index) => <div key={round.id} className="flex items-center gap-3 border-b border-[hsl(var(--border))] py-3 last:border-0"><span className="font-data text-[10px] text-[hsl(var(--muted-foreground))]">{String(index + 1).padStart(2, "0")}</span><div className="h-1.5 flex-1 rounded-full bg-[hsl(var(--muted))]"><div className="h-full rounded-full bg-[hsl(var(--accent))]" style={{ width: `${Math.max(8, (round.multiplier / stats.highest) * 100)}%` }} /></div><span className="font-data text-sm">{formatMultiplier(round.multiplier)}</span></div>)}</div></section></div><div className="mt-5 rounded-2xl border border-[hsl(232_56%_52%/.2)] bg-[hsl(232_56%_52%/.06)] p-5"><div className="flex gap-3"><Info size={18} className="mt-0.5 shrink-0 text-[hsl(var(--primary))]" /><div><h3 className="text-sm font-semibold text-[hsl(232_48%_35%)]">How to read this page</h3><p className="mt-1 max-w-2xl text-xs leading-relaxed text-[hsl(232_40%_42%)]">Distribution tells you what has appeared in your sample. It does not describe likelihood, fairness, or what will happen next. Keep the distinction visible.</p></div></div></div></>}
    </AppFrame>
  );
}

export function SettingsPage() {
  const { rounds, capacity, thresholds, setCapacity, setThresholds, resetRounds } = useCrashRounds();
  const [compact, setCompact] = useState(false);
  const [showBands, setShowBands] = useState(true);
  const [confirmReset, setConfirmReset] = useState(false);
  const [message, setMessage] = useState("");
  const [lowMax, setLowMax] = useState(String(thresholds.lowMax));
  const [mediumMax, setMediumMax] = useState(String(thresholds.mediumMax));
  function reset() {
    resetRounds();
    setConfirmReset(false);
    setMessage("Demo history restored. Your notebook is ready to review.");
  }
  return (
    <AppFrame>
      <PageHeading eyebrow="Settings / preferences" title="Tune the instrument." description="Small display choices for a calmer review loop. Your data controls live in this browser." />
      <div className="grid gap-5 lg:grid-cols-[1fr_.72fr]">
        <section className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-7">
          <SectionLabel>Display preferences</SectionLabel>
          <h2 className="font-display text-2xl font-semibold tracking-[-.035em]">Make the readout yours</h2>
          <div className="mt-6 divide-y divide-[hsl(var(--border))]">
            {[{ label: "Compact history rows", hint: "Tighten the spacing in long round logs.", value: compact, set: setCompact }, { label: "Show range labels", hint: "Keep LOW, MEDIUM, and HIGH labels visible.", value: showBands, set: setShowBands }].map((item) => <div key={item.label} className="flex items-center justify-between gap-5 py-5 first:pt-0 last:pb-0"><div><div className="text-sm font-semibold">{item.label}</div><div className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">{item.hint}</div></div><button onClick={() => item.set(!item.value)} className={`relative h-7 w-12 shrink-0 rounded-full p-1 transition-colors ${item.value ? "bg-[hsl(var(--primary))]" : "bg-[hsl(var(--muted-foreground)/.35)]"}`} role="switch" aria-checked={item.value} data-testid={`switch-${item.label.toLowerCase().replaceAll(" ", "-")}`}><span className={`block h-5 w-5 rounded-full bg-[hsl(var(--card))] shadow-sm transition-transform ${item.value ? "translate-x-5" : "translate-x-0"}`} /></button></div>)}
          </div>
           <div className="mt-8 border-t border-[hsl(var(--border))] pt-6"><div className="flex items-center gap-2 text-xs font-semibold"><Database size={14} className="text-[hsl(var(--primary))]" /> History capacity</div><p className="mt-2 text-xs leading-relaxed text-[hsl(var(--muted-foreground))]">Choose how many rounds this browser keeps locally.</p><div className="mt-4 grid grid-cols-4 gap-2">{([100, 500, 1000, 5000] as HistoryCapacity[]).map((option) => <button key={option} onClick={() => setCapacity(option)} className={`rounded-xl border px-2 py-3 font-data text-[11px] ${capacity === option ? "border-[hsl(var(--primary))] bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]" : "border-[hsl(var(--border))]"}`} aria-pressed={capacity === option} data-testid={`button-capacity-${option}`}>{option.toLocaleString()}</button>)}</div><p className="mt-2 text-[10px] text-[hsl(var(--muted-foreground))]">{capacity.toLocaleString()} round maximum</p></div>
           <div className="mt-8 border-t border-[hsl(var(--border))] pt-6"><div className="flex items-center gap-2 text-xs font-semibold"><SlidersHorizontal size={14} className="text-[hsl(var(--primary))]" /> Analysis bands</div><p className="mt-2 text-xs leading-relaxed text-[hsl(var(--muted-foreground))]">Set the upper bounds used for LOW and MEDIUM classification. HIGH begins above MEDIUM.</p><div className="mt-4 grid grid-cols-2 gap-3"><label className="text-[10px] uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))]">LOW through<input value={lowMax} onChange={(event) => setLowMax(event.target.value)} inputMode="decimal" className="mt-2 w-full rounded-xl border border-[hsl(var(--input))] bg-[hsl(var(--background)/.55)] px-3 py-3 font-data text-sm" /></label><label className="text-[10px] uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))]">MEDIUM through<input value={mediumMax} onChange={(event) => setMediumMax(event.target.value)} inputMode="decimal" className="mt-2 w-full rounded-xl border border-[hsl(var(--input))] bg-[hsl(var(--background)/.55)] px-3 py-3 font-data text-sm" /></label></div><button onClick={() => { const low = Number(lowMax); const medium = Number(mediumMax); if (!Number.isFinite(low) || !Number.isFinite(medium) || low < 1 || medium <= low) { setMessage("Use ordered values: LOW ≥ 1.00 and MEDIUM greater than LOW."); return; } setThresholds({ lowMax: low, mediumMax: medium }); setMessage("Analysis bands saved locally."); }} className="mt-4 rounded-xl bg-[hsl(var(--primary))] px-4 py-2.5 text-xs font-semibold text-[hsl(var(--primary-foreground))]" data-testid="button-save-analysis-bands">Save analysis bands</button></div>
           <div className="mt-8 border-t border-[hsl(var(--border))] pt-6"><div className="flex items-center gap-2 text-xs font-semibold"><Database size={14} className="text-[hsl(var(--primary))]" /> History capacity</div><p className="mt-2 text-xs leading-relaxed text-[hsl(var(--muted-foreground))]">Choose how many rounds this browser keeps locally.</p><div className="mt-4 grid grid-cols-4 gap-2">{([100, 500, 1000, 5000] as HistoryCapacity[]).map((option) => <button key={option} onClick={() => setCapacity(option)} className={`rounded-xl border px-2 py-3 font-data text-[11px] ${capacity === option ? "border-[hsl(var(--primary))] bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]" : "border-[hsl(var(--border))]"}`} aria-pressed={capacity === option} data-testid={`button-capacity-${option}`}>{option.toLocaleString()}</button>)}</div><p className="mt-2 text-[10px] text-[hsl(var(--muted-foreground))]">{capacity.toLocaleString()} round maximum</p></div>
          <div className="mt-8 border-t border-[hsl(var(--border))] pt-6"><div className="flex items-center gap-2 text-xs font-semibold"><SlidersHorizontalIcon /> Interface notes</div><p className="mt-2 text-xs leading-relaxed text-[hsl(var(--muted-foreground))]">Preferences apply immediately for this session. The analyzer always stays in light mode so the visual language remains consistent and easy to scan.</p></div>
        </section>
        <div className="space-y-5">
          <section className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-6"><SectionLabel>Local storage</SectionLabel><div className="flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[hsl(var(--secondary))] text-[hsl(var(--primary))]"><Database size={18} /></div><div><h2 className="font-display text-xl font-semibold">This device only</h2><p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">{rounds.length} rounds stored locally</p></div></div><div className="mt-5 flex items-center gap-2 text-xs text-[hsl(175_35%_28%)]"><Check size={14} /> No server connection required</div></section>
          <section className="rounded-2xl border border-[hsl(var(--accent)/.25)] bg-[hsl(var(--accent)/.06)] p-5 sm:p-6"><SectionLabel>Reset notebook</SectionLabel><h2 className="font-display text-xl font-semibold">Start over with demo data</h2><p className="mt-2 text-xs leading-relaxed text-[hsl(var(--muted-foreground))]">Remove your current observations and restore the built-in example set. This cannot be undone.</p>{!confirmReset ? <button onClick={() => setConfirmReset(true)} className="mt-5 inline-flex items-center gap-2 rounded-xl border border-[hsl(var(--accent)/.35)] px-3.5 py-2.5 text-xs font-semibold text-[hsl(14_68%_47%)]" data-testid="button-reset-data"><RotateCcw size={14} /> Reset local data</button> : <div className="mt-5 rounded-xl border border-[hsl(var(--accent)/.3)] bg-[hsl(var(--card)/.7)] p-3"><p className="text-xs font-semibold">Reset all recorded rounds?</p><div className="mt-3 flex gap-2"><button onClick={reset} className="rounded-lg bg-[hsl(var(--accent))] px-3 py-2 text-xs font-semibold text-[hsl(var(--accent-foreground))]" data-testid="button-confirm-reset">Yes, reset</button><button onClick={() => setConfirmReset(false)} className="rounded-lg border border-[hsl(var(--border))] px-3 py-2 text-xs font-semibold" data-testid="button-cancel-reset">Cancel</button></div></div>}{message && <div className="mt-3 flex gap-2 text-xs text-[hsl(175_35%_28%)]" data-testid="status-reset"><Check size={14} /> {message}</div>}</section>
        </div>
      </div>
      <div className="mt-5 flex items-center gap-2 text-[11px] text-[hsl(var(--muted-foreground))]"><CircleHelp size={14} /> Crash Speed Analyzer is a historical analysis companion. It never provides future predictions.</div>
    </AppFrame>
  );
}

function SlidersHorizontalIcon() {
  return <SlidersHorizontal size={14} className="text-[hsl(var(--primary))]" />;
}