import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.crashspeedanalyzer.app",
  appName: "Crash Speed Analyzer",
  webDir: "dist/public",
  android: {
    backgroundColor: "#F4F5EE",
  },
};

export default config;